import math

#ai é só usar as funções que estão dentro da biblioteca