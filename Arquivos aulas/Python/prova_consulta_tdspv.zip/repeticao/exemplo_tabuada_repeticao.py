n = int(input("Informe inteiro: "))

#print(n, " X 1 =", (n * 1))
#print(n, " X 2 =", (n * 2))
#print(n, " X 3 =", (n * 3))
#print(n, " X 4 =", (n * 4))

i = 1

while i <= 100:
    print(f"{n} X {i} = {(n * i)}")
    i = i + 1

