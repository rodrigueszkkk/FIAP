numero = int(input("Numero: "))

n = 1

while n <= numero:
    print(n)
    n = n + 1
