valor = input("Digite um numero: ")
print(valor)