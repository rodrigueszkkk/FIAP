print("Hoje é sexta-feira!")
