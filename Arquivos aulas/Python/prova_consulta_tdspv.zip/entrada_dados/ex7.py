aux = input("Digite um número: ")
num = int(aux)

dezena = num // 10
unidade = num % 10

print("Dezena: ", dezena, " unidade: ", unidade)