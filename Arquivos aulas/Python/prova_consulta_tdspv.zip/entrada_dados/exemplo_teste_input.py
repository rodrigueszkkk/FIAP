nome = input("Digite o seu nome: ")

email = input("Informe o seu email: ")

print(nome)
print(email)

x = 47.3
y = 47.999

print(type(x))
print(type(nome))

print(    int(x)   )
print(    int(y)   )

facul = " FIAP "
facul = facul * 4
print(facul)

