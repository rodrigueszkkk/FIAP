valor = input("Digite um valor: ")
num_a = int(valor)

valor = input("Digite um valor: ")
num_b = int(valor)

soma = num_a + num_b
print(soma)
