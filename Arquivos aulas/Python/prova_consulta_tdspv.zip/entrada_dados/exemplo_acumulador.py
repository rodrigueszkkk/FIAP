soma = 0

valor = input("Numero: ")
num = int(valor)
soma = soma + num

valor = input("Numero: ")
num = int(valor)
soma = soma + num

valor = input("Numero: ")
num = int(valor)
soma = soma + num

valor = input("Numero: ") 
num = int(valor)
soma = soma + num

print(soma)