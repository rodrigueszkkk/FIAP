
# Exercício 2 – Imprimir todos os números da tupla um por um
numeros = (3, 7, 11, 18, 24, 33, 42, 56, 67, 74, 85, 91, 102, 114, 125)
for numero in numeros:
    print(numero)
