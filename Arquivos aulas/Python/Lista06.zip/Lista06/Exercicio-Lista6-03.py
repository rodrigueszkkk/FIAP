
# Exercício 3 – Função que retorna o maior valor da tupla
def maior_valor(tupla):
    return max(tupla)

print(maior_valor((3, 7, 11, 18, 24, 33, 42, 56, 67)))
