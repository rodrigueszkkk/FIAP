
# Exercício 5 – Função que retorna a maior String da tupla
def maior_string(tupla):
    return max(tupla, key=len)

print(maior_string(("Gabriel", "Amanda", "Jonathan", "Lucas", "Ana")))
