
# Exercício 4 – Função que retorna a média dos valores da tupla
def media_valores(tupla):
    return sum(tupla) / len(tupla)

print(media_valores((10.5, 7.2, 9.8, 5.5, 6.6)))
